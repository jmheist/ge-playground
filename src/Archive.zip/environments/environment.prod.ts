export const environment = {
  production: true,
  firebase: {
  	apiKey: "AIzaSyCcA6KyePSLIA3WvXVRjMYke_6PasHpVvk",
    authDomain: "giftexchange-572f3.firebaseapp.com",
    databaseURL: "https://giftexchange-572f3.firebaseio.com",
    projectId: "giftexchange-572f3",
    storageBucket: "giftexchange-572f3.appspot.com",
    messagingSenderId: "184436074227"
  }
};
