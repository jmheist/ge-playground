export interface WishlistItem {
    name?: '';
    url?: '';
    uid?: '';
  }